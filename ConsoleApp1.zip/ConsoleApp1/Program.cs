﻿using System;
using System.Collections.Generic;
using System.Text;


namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Isik inimene1 = new Isik();
            //inimene1.Nimi = "Mati";
            //inimene1.Sünniaasta = 2000;
            //inimene1.Tervita(); // Väljund: Tere! Mina olen Mati...

            Õpetaja õpetaja1 = new Õpetaja();
            õpetaja1.Nimi = "Arkadi";
            õpetaja1.Sünniaasta = 2000;
            õpetaja1.Aine = "Programmeerimine";
            õpetaja1.Kirjelda();
            õpetaja1.Õpeta();

            Õpilane õpilane1 = new Õpilane();
            õpilane1.Nimi = "Martin";
            õpilane1.Sünniaasta = 2005;
            õpilane1.Kool = "TTHK";
            õpilane1.Klass = 12;
            õpilane1.Kirjelda();
            õpilane1.Õpi();
        }
    }
}