﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    public interface ITööline
    {
        double ArvutaPalk(); // Ainult meetodi allkiri
    }

    // Õpetaja pärib Isik klassist JA rakendab ITööline liidest
    public class Õpetaja : Isik, ITööline
    {
        public double Tunnitasu { get; set; }
        public int TunnidNädalas { get; set; }

        public override void Kirjelda()
        {
            Console.WriteLine($"Õpetaja {Nimi}.");
        }

        // Kohustuslik meetod liidesest
        public double ArvutaPalk()
        {
            return Tunnitasu * TunnidNädalas * 4; // Kuupalk
        }
    }
}
